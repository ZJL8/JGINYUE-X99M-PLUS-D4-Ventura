# Config
- JGYINYUE X99M PLUS D4
- E5 2680v3
- RX 580 8G(2048sp) <br>
    flash vbios: RX 570 8G 
- 32g (16*2 2666MHZ)
- 1T (GT 34)
- Haven't WIFI and Bluetooth
 
